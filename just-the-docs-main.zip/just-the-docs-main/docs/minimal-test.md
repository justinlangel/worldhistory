---
layout: minimal
title: Minimal layout test
nav_exclude: true
---

[Return to main website]({{site.baseurl}}/).

This page demonstrates the packaged `minimal` layout, which does not render the sidebar or header. It can be used for standalone pages. It is also an example of using the new modular site components to define custom layouts; see ["Custom layouts and includes" in the customization docs]({{site.baseurl}}/docs/customization/#custom-layouts-and-includes) for more information.
